import re

minWortLaenge = 4
maxWortLaenge = 20
initprob = 0.5          # Initiale Wahrscheinlichkeit
BlackList = ['doch', 'einer', 'sich', 'oder', 'einem', 'einer', 
			 'will', 'nger', 'soll', 'alle', 'rund', 'eignet', 
			 'gegen', 'einen', 'lassen', 'besonders', 'sind', 
			 'sehr', 'neue', 'auch', 'nach', 'besten', 'wwdc',
			 'ihnen', 'ihren', 'lediglich', 'nnen']

class Classifier:  
	fc = {}         # Speichert die Worte, sowie ihre Haeufigkeit in den Klassen
	cc = {}         # Speichert die Anzahl der Dokumente in den beiden Klassen
	getfeatures = 0 # Methode um Woerter aus Dokument zu holen
	
	g = ""
	b = ""
	
	def __init__(self, getfeatures, good, bad):
		self.g = good
		self.b = bad
		self.getfeatures = getfeatures
		self.cc[self.g] = self.cc[self.b]  = 0     # Initialisiert beide Klassen mit 0
		
	def incf(self, f, cat):                        # Fuellt Woerter in Dictionary fc{} ein
		if f not in self.fc:                       # Ist das Wort neu?
			self.fc[f] = {self.g: 0, self.b: 0}    # Wenn neu, dann initialisieren
		self.fc[f][cat] += 1                       
		
	def incc(self, cat):                           # Erhoeht den Kategorien-Zaehler
		self.cc[cat] = self.cc[cat] + 1            
		
	def fcount(self, f, cat):                      # Gibt zurueck, wie oft das Wort in der Kategorie auftaucht
		if f in self.fc:                           # Wenn das Wort schon bekannt ist
			return self.fc[f][cat]                
		else:                                      # Wenn wir noch keine Aussage treffen koennen
			return 0.5                             
		
	def catcount(self, cat):                       # Wieviele Dokumente der Kategorie gelesen wurden
		return self.cc[cat]                        
	
	def totalcount(self):                          # Gesamtzahl gelesener Dokumente
		return self.cc[self.g] + self.cc[self.b]  
	
	def train(self, text, cat):                    # "Lernt" ein Test-Dokument
		textList = self.getfeatures(text)          
		for wort in textList:                     
			self.incf(wort, cat)                   
		self.incc(cat)                             
	
	def fprob(self, f, cat):                                           # P(f|cat) 
		return float(self.fcount(f, cat)) / float(self.catcount(cat))  # P(f|cat)= (Wie oft ist f in cat?) / (Wie oft Dokumente von cat?)

	def weightedprob(self, f, cat):                                            # Umgehen des Kaltstartproblems	
		if (f in self.fc):
		  count = self.fc[f][self.g] + self.fc[f][self.b]                      # Je hauefiger das Wort vorkommt, desto weniger wird initpob beruecksichtigt 
		else:
			count = 0
		return ( initprob + count * self.fprob(f, cat) ) / ( 1 + count )       # Ohne initprob wuerden bei 0 Woertern 0 zurueck kommen
	
	def prob(self, item, cat):                                                 # Bewertet ein Dokument
		string = self.getfeatures(item)
		erg = 1.0
		for wort in string:
			erg = erg * self.weightedprob(wort, cat)                           # Produkt aller bedingten Wahrscheinlichkeiten
		return erg * ( float(self.catcount(cat)) / float(self.totalcount()) )  # a-postiori Wahrscheinlichkeit: Wir oft taucht eine best. Klasse auf?
	
	def learned(self):                                                         # Gibt einer kurze Uebersicht ueber den Classifier
		s = 'Gelernte Worte:\n'
		s += '  > Doks ' + self.g + ':  ' + str(self.catcount(self.g)) + '\n'
		s += '  > Doks ' + self.b + ':   ' + str(self.catcount(self.b))  + '\n'
		s += '  > Doks total: ' + str(self.totalcount())     + '\n'
		for wort in self.fc: s += '\t' + wort + '\t\t' + str(self.fc[wort]) + '\n'
		return s
		
	def printMostInformative(self):                                            # Gibt die am staerksten klassifizierenden 10 Features aus
		list = []
		for e in self.fc:
			dif = abs( self.fc[e][self.g] -self.fc[e][self.b] )
			list.append((dif, e))
		list.sort()
		list.reverse()
		print "Most Informative (10):"
		for i in range(10):
			print str(list[i][0]) + ", " + str(list[i][1]) + ", " + str(self.fc[list[i][1]])
		
def getTextFile(url):          # Liest eine Datei aus und gibt deren Inhalt als String
	file = open(url,"r")      
	textFile = file.read()     
	file.close                 
	return textFile         

def getWordsList(doc):                                                  # teilt einen String in Wort und setzt sie auf Lower-Case          
	doc = doc.lower()                                                  
	wortListe = re.split(r'[^\w-]+', doc)                                 
	s = set()
	for wort in wortListe:                                             
		if wort.__len__() >= minWortLaenge and wort.__len__() <= maxWortLaenge: 
			if wort not in BlackList:
				s.add(wort)   
	return s                                                    #

# Test
if __name__ == "__main__":
	cl = Classifier(getWordsList, "Good", "Bad")                            # Instantiieren der Klasse "Classifier"
	
	# Es werden jeweils 5 Dokumente mit guten und schlechten Woertern gelernt
	cl.train(getTextFile('s_good_1.txt'), 'Good')   
	cl.train(getTextFile('s_good_2.txt'), 'Good')   
	cl.train(getTextFile('s_good_3.txt'), 'Good')  
	cl.train(getTextFile('s_good_4.txt'), 'Good')   
	cl.train(getTextFile('s_good_5.txt'), 'Good')   
	cl.train(getTextFile('s_bad_1.txt'), 'Bad')    
	cl.train(getTextFile('s_bad_2.txt'), 'Bad')    
	cl.train(getTextFile('s_bad_3.txt'), 'Bad')   
	cl.train(getTextFile('s_bad_4.txt'), 'Bad')    
	cl.train(getTextFile('s_bad_5.txt'), 'Bad')
	
	print cl.learned()
	cl.printMostInformative()
	
	# Test-Ausgabe
	print '     P("the money jumps"|Good)= ' + str(cl.prob("the money jumps", 'Good'))
	print '     P("the money jumps"|Bad) = ' + str(cl.prob("the money jumps", 'Bad'))